#include <iostream>

using namespace std;

int i,k;

int main()
{
    for(i=1;i<=5;i++)
    {

        for(k=1;k<=i;k++)
        {
           cout<<k;

        }
        cout<<"\n";
    }

}
