#include <iostream>

using namespace std;

char caracter;

int main()
{
    cout << "Ingresar un caracter: ";
    cin>>caracter;

    switch(caracter)
    {
    case 'a':
        cout<<" Es una vocal ";
        break;
    case 'e':
        cout<<" Es una vocal ";
        break;
    case 'i':
        cout<<" Es una vocal ";
        break;
    case 'o':
        cout<<" Es una vocal ";
        break;
    case 'u':
        cout<<" Es una vocal ";
        break;
    case 'A':
        cout<<" Es una vocal ";
        break;
    case 'E':
        cout<<" Es una vocal ";
        break;
    case 'I':
        cout<<" Es una vocal ";
        break;
    case 'O':
        cout<<" Es una vocal ";
        break;
    case 'U':
        cout<<" Es una vocal ";
        break;
    default:
        cout<<" No es una vocal ";
        break;

    }

}
